﻿namespace Thrume.Domain.DTOs;

public record struct UpdateAccountResponse;